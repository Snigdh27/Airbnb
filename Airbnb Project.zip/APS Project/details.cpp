#include<bits/stdc++.h>
#include<fstream>
using namespace std;

void info(){
    ifstream customers;
    string customer;
    customers.open("customers.txt");
    while (customers.eof()==0)
    {
        getline(customers,customer);
        cout<<customer<<endl;
    }
}

int main(){
    system("cls");
    cout<<"\n\n\n\n\t\t\t\t\t\t\tMENU\n";
    cout<<"\n\n";
    cout<<"\t\t\t\t\t 1)User Login \n \t\t\t\t\t 2)Owner Login \n\n";
    /*info();*/
    

}