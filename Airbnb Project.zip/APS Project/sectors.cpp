#include<bits/stdc++.h>
#include<fstream>
using namespace std;

int main(){
    ifstream address,price;
    string stAdd,stPrice;
    address.open("address.txt");
    price.open("price.txt");
    while (address.eof()==0)
    {
        getline(address,stAdd);
        getline(price,stPrice);
        cout<<stAdd<<"  "<<stPrice<<endl;
    }

    return 0;

}
