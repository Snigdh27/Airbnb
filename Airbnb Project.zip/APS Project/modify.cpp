#include<bits/stdc++.h>
#include<fstream>
using namespace std;

int searchId(){
    int id;
    cout<<"Enter your seller Id\n";
    cin>>id;
    int list;
    ifstream read;
    read.open("id.txt");
    while(!read.eof()){
        read>>list;
        if(list==id){
            cout<<"Id matched\n";
            return id;
        }
    }
    return -1;
}

void modifyDetails(){
    int id=searchId();
    cout<<"\nDo You Want to Modify Details (Y/N) : ";
    char choice;
    cin>>choice;
    if(choice=='y' || choice=='Y'){
        int customerId;
        cout<<"Enter your new details\n";
        string Add,name,room;
int sector,av;
double price;
cout<<"Enter Name:";
cin>>name;
cout<<"Enter Address:";
cin>>Add;
cout<<"Enter Sector:";
cin>>sector;
cout<<"Enter room type:";
cin>>room;
cout<<"Enter price:";
cin>>price;
cout<<"Enter availaible days:";
cin>>av;
ifstream addresses,prices,sectors,names,avail,r_type;
        
        ofstream temp_name,temp_address,temp_price,temp_sector,temp_avail,temp_rtype;
           addresses.open("address.txt");
    names.open("name.txt");
    prices.open("price.txt");
    sectors.open("sectors.txt");
    avail.open("availability.txt");
    r_type.open("room.txt");
        temp_name.open("tempname.txt");
        temp_address.open("tempaddress.txt");
        temp_price.open("tempprice.txt");
        temp_sector.open("tempSectors.txt");
        temp_avail.open("tempavail.txt");
        temp_rtype.open("tempr_type.txt");
        ifstream read;
        read.open("id.txt");
        while(!read.eof()){
            read>>customerId;
            string acc_name,acc_add,acc_room;
            double acc_price;
            int acc_sector,acc_av;
            if(customerId==id){
                temp_name<<name<<"\n";
                temp_address<<Add<<"\n";
                temp_price<<price<<"\n";
                temp_sector<<sector<<"\n";
                temp_avail<<av<<"\n";
                temp_rtype<<room<<"\n";
            }
            else{
                names>>acc_name;
                temp_name<<acc_name<<"\n";
                addresses>>acc_add;
                temp_address<<acc_add<<"\n";
                prices>>acc_price;
                temp_price<<acc_price<<"\n";
                sectors>>acc_sector;
                temp_sector<<acc_sector<<"\n";
                avail>>acc_av;
                temp_avail<<acc_av<<"\n";
                r_type>>acc_room;
                temp_rtype<<acc_room<<"\n";
            }
        }
        read.close();
        names.close();
        addresses.close();
        prices.close();
        sectors.close();
        avail.close();
        r_type.close();
        temp_name.close();
        temp_address.close();
        temp_price.close();
        temp_sector.close();
        temp_avail.close();
        temp_rtype.close();
        remove("name.txt");
        remove("address.txt");
        remove("availability.txt");
        remove("price.txt");
        remove("room.txt");
        remove("sectors.txt");
        rename("tempname.txt","name.txt");
        rename("tempaddress.txt","address.txt");
        rename("tempprice.txt","price.txt");
        rename("tempSectors.txt","sectors.txt");
        rename("tempavail.txt","availability.txt");
        rename("tempr_type.txt","room.txt");
        cout<<"Data modified successfully\n";
    }
    else{
        cout<<"Data not modified\n";
    }
}

int main(){
    system("cls");
    modifyDetails();
}